#!/bin/sh
python3 351dns.py $1 $2 $3

